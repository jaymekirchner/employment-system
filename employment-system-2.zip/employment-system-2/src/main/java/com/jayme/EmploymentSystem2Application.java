package com.jayme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmploymentSystem2Application {

	public static void main(String[] args) {
		SpringApplication.run(EmploymentSystem2Application.class, args);
	}

}
